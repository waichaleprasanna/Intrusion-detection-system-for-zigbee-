# Sniffer firmware

CC2531 USB dongles running TI packet-sniffer firmware are used to capture IEEE 802.15.4 / Zigbee traffic.
Captured frames are passed to Wireshark through the TI Wireshark Packet Converter pipe and to `src/sniffer.py`.

- Hardware: CC2531 dongle + CC Debugger
- Firmware file: _add the filename here_
- Source: _add the download link and version here_
- SHA-256: _run `certutil -hashfile <file> SHA256` and paste it here_

Flash with SmartRF Flash Programmer exactly as described in `../coordinator/README.md`.
