# Jamming attack
**What:** interference that disrupts the channel.
**Detection:** abnormal traffic drops or noise patterns.
**Try it:** trigger Jamming from the dashboard with detection OFF, then ON.
